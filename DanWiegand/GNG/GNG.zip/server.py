import random
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'thisissecret'

@app.route('/')
def index():
    session['secret'] = random.randint(0, 101)
    return render_template('index.html')

@app.route('/guess', methods=['POST'])
def guess():
    session['guess'] = request.form['guess']
    return render_template('index.html', guess=session['guess'])
app.run(debug=True)
