from django.shortcuts import render, redirect
from django.utils.crypto import get_random_string

# Create your views here.
def index(request):
    if not 'count' in request.session:
        request.session['count'] = 0;
    else:
        request.session['count'] += 1
    return render(request, 'randomword/index.html')

def word(request):
    if not 'randomword' in request.session:
        request.session['randomword'] = get_random_string(length=14)
    else:
        request.session['randomword'] = get_random_string(length=14)
    return redirect('/')
