from django.shortcuts import render, redirect, HttpResponse
from .models import User
from django.contrib import messages

def index(request):
    return render(request, 'validation/index.html')

def register(request):
    if User.objects.registration(request.POST['email'])==True :
        User.objects.create(email=request.POST['email'])
        return redirect('/success')
    else:
        messages.error(request, 'Must use a valid email.')
        return redirect('/')

def success(request):
    context = {
    'emails' : User.objects.all()
    }
    return render(request, 'validation/success.html', context)
