from __future__ import unicode_literals
from decimal import *
from django.db import models

class PetManager(models.Manager):
    def pet_val(self, data):
        errors = []
        if len(data['name']) < 1:
            errors.append('Name field must not be empty.')
        if len(data['description']) < 4:
            errors.append('Please provide a brief description.')
        if not data['price']:
            errors.append('Must include a price!')
        return errors

class Pet(models.Model):
    name = models.CharField(max_length=45)
    description = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = PetManager()

# Create your models here.
