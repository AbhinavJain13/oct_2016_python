from django.shortcuts import render, redirect
from .models import Pet
from django.contrib import messages

def index(request):
    context={
    'pets': Pet.objects.all()
    }
    return render(request, 'routes/index.html', context)

def new(request):
    return render(request, 'routes/new.html')

def create(request):
    error_messages=Pet.objects.pet_val(request.POST)
    if error_messages:
        for error in error_messages:
            messages.error(request, error)
        return redirect('pets:new')
    else:
        petvals = {'name': request.POST['name'], 'description': request.POST['description'], 'price': request.POST['price']}
        Pet.objects.create(**petvals)
    return redirect('pets:index')

def show(request, id):
    context = {
    'pet': Pet.objects.filter(id=id)
    }
    return render(request, 'routes/show.html', context)

def edit(request, id):
    context = {
    'pet': Pet.objects.filter(id=id)
    }
    return render(request, 'routes/edit.html', context)

def update(request, id):
    error_messages=Pet.objects.pet_val(request.POST)
    if error_messages:
        for error in error_messages:
            messages.error(request, error)
        return redirect('pets:edit', id=id)
    else:
        petvals = {'name': request.POST['name'], 'description': request.POST['description'], 'price': request.POST['price']}
        Pet.objects.filter(id=id).update(**petvals)
    return redirect('pets:index')

def destroy(request, id):
    Pet.objects.filter(id=id).delete()
    return redirect('pets:index')
