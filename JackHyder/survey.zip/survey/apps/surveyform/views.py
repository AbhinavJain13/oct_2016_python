from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages

def index(request):
    if 'count' not in request.session:
        request.session['count'] = 0
    return render(request, 'surveyform/index.html')

def process(request):
    if request.method == "POST":
        request.session['count'] += 1
        request.session['name']= request.POST['name']
        request.session['Location']= request.POST['Location']
        request.session['Language']= request.POST['Language']
        request.session['comment']= request.POST['comment']
        if len(request.POST['name']) < 1 or len(request.POST['comment']) < 1 :
            messages.error(request, 'Must have a name and comment (comment not actually optional)!')
            return redirect('/')
        elif len(request.POST['comment']) > 120:
            messages.error(request, 'Comment must be less than 120 characters')
            return redirect('/')
        else:
            return redirect('/results')
    else:
        return redirect('/')

def results(request):
    return render(request, 'surveyform/results.html')
