from flask import Flask, render_template, request, redirect, session, flash
import os, binascii, md5, re, bcrypt
from mysqlconnection import MySQLConnector

app = Flask(__name__)
app.secret_key= 'secretkey'
mysql = MySQLConnector(app, 'login')

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX = re.compile(r'^[A-z]+$')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['post'])
def register():
     first_name = request.form['first_name']
     last_name = request.form['last_name']
     email = request.form['email']
     password = md5.new(request.form['password']).hexdigest();
     query = "INSERT INTO users (first_name, last_name, email, password, created_at, updated_at) VALUES ( :first_name, :last_name, :email, :password, NOW(), NOW())"
     data = { 'first_name': first_name, 'last_name': last_name, 'email': email, 'password': password }
     mysql.query_db(query, data)
     if len(request.form['first_name']) < 2 or not NAME_REGEX.match(request.form['first_name']):
         flash("First and last names must be at least 2 characters and consist of letters only")
         return redirect('/')
     elif len(request.form['last_name']) < 2 or not NAME_REGEX.match(request.form['last_name']):
         flash("First and last names must be at least 2 characters and consist of letters only")
         return redirect('/')
     elif not EMAIL_REGEX.match(request.form['email']):
         flash("Use a real email.")
         return redirect('/')
     elif len(request.form['password']) < 8:
         flash("Passwords must be at least 8 characters")
         return redirect('/')
     elif request.form['password'] != request.form['confirm_password']:
         flash("Confirm password must be the same as password")
         return redirect('/')
     else:
         flash("Thanks for registering")
         return redirect('/')

@app.route('/login', methods=['post'])
def login():
    #if email and password match database, session id becomes user's id?
    email = request.form['email']
    password = md5.new(request.form['password']).hexdigest();
    query = 'SELECT * FROM users WHERE email= :email'
    data = {
    'email': email
    }
    users = mysql.query_db(query, data)[0]
    if password == users['password']:
        session['email'] = request.form['email']
        flash('you are now logged in')
        return redirect('/')
    else:
        flash('email and password do not match')
        return redirect('/')

app.run(debug=True)
