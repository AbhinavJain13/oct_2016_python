from django.shortcuts import render, redirect, HttpResponse
from .models import Course, User
from django.core.urlresolvers import reverse
from django.contrib import messages

def index(request):
    context = {
    'courses' : Course.objects.all()
    }
    return render(request, 'coursecreator/index.html', context)

def createcourse(request):
    Course.objects.create(course_name=request.POST['course_name'], course_description=request.POST['course_description'])
    return redirect('courses:index')

def delete(request, course_number):
    context = {
    'courses' : Course.objects.filter(id=course_number)
    }
    return render(request, 'coursecreator/destroy.html', context)

def destroy(request, course_number):
    Course.objects.filter(id=course_number).delete()
    return redirect('courses:index')

def usercourse(request):
    if request.method=='POST':
        Course.objects.AddUser(request.POST)
        if Course.objects.AddUser(request.POST) == False:
            messages.error(request, 'User already in this course')
    context = {
    'courses' : Course.objects.all(),
    'users' : User.objects.all()
    }
    return render(request, 'coursecreator/users_courses.html', context)
