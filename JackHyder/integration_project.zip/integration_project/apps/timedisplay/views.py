from django.shortcuts import render, HttpResponse

def index(request):
    return render(request, 'timedisplay/index.html')


# Create your views here.
