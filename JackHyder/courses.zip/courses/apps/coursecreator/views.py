from django.shortcuts import render, redirect
from .models import Course

def index(request):
    context = {
    'courses' : Course.objects.all()
    }
    return render(request, 'coursecreator/index.html', context)

def createcourse(request):
    Course.objects.create(course_name=request.POST['course_name'], course_description=request.POST['course_description'])
    return redirect('/')

def delete(request, course_number):
    context = {
    'courses' : Course.objects.filter(id=course_number)
    }
    return render(request, 'coursecreator/destroy.html', context)

def destroy(request, course_number):
    Course.objects.filter(id=course_number).delete()
    return redirect('/')
