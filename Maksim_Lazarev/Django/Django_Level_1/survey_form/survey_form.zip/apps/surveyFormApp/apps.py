from django.apps import AppConfig


class SurveyformappConfig(AppConfig):
    name = 'surveyFormApp'
