from django.apps import AppConfig


class DisappearingninjasConfig(AppConfig):
    name = 'disappearingNinjas'
