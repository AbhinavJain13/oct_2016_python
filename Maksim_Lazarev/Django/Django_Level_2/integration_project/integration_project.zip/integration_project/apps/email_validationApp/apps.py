from django.apps import AppConfig


class EmailValidationappConfig(AppConfig):
    name = 'email_validationApp'
